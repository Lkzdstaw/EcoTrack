# EcoTrack

**EcoTrack** is a lightweight open-source platform designed to collect, store, and visualize real-time environmental data from public APIs around the world. This includes metrics such as air quality index (AQI), water pollution levels, and weather conditions.

The main goal of EcoTrack is to provide a simple, centralized dashboard for environmental researchers, students, and eco-enthusiasts to monitor ecological changes with ease.

## Features

- Aggregates data from multiple public APIs (OpenWeatherMap, WAQI, etc.)
- Real-time visualization with interactive charts
- Modular architecture for easy extension
- Lightweight backend using Python (FastAPI or Flask)
- Simple HTML/JS frontend with Chart.js

## Planned Integrations

- OpenWeatherMap API (temperature, humidity, etc.)
- World Air Quality Index (AQI)
- Water quality APIs (e.g., RiverPollutionData API)
- NASA Earth data sources (TBD)

## Tech Stack

- Python 3.10+
- FastAPI or Flask
- JavaScript (Vanilla or Vue)
- Chart.js
- Hosted via lightweight VPS

## Example Data (WIP)

```json
{
  "city": "Hong Kong",
  "aqi": 78,
  "temperature": 29.3,
  "humidity": 82,
  "timestamp": "2025-04-29T10:00:00Z"
}
```

## Project Status

Early development phase – backend API and data visualizer under construction.  
Live demo will be hosted once VPS access is granted.

## License

MIT License

## Author

Mike Tom – [lkzdstaw@gmail.com](mailto:lkzdstaw@gmail.com)

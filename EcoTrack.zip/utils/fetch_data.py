import requests

def fetch_aqi():
    response = requests.get("https://api.waqi.info/feed/hongkong/?token=YOUR_API_TOKEN")
    if response.status_code == 200:
        data = response.json()
        print("AQI:", data['data']['aqi'])

if __name__ == '__main__':
    fetch_aqi()

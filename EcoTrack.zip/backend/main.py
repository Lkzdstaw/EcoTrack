from flask import Flask, jsonify
app = Flask(__name__)

@app.route('/api/data')
def get_data():
    return jsonify({
        "city": "Hong Kong",
        "aqi": 78,
        "temperature": 29.3,
        "humidity": 82,
        "timestamp": "2025-04-29T10:00:00Z"
    })

if __name__ == '__main__':
    app.run(debug=True)
